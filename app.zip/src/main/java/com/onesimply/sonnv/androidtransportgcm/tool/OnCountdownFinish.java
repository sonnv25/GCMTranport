package com.onesimply.sonnv.androidtransportgcm.tool;

/**
 * Created by N on 15/03/2016.
 */
public interface OnCountdownFinish {
        void onCountdownFinish();
}
